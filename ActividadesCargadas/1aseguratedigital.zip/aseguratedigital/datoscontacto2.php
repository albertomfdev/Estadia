<?php
header('Access-Control-Allow-Origin: *');	
require 'PHPMailer/PHPMailerAutoload.php';
//header('Access-Control-Allow-Origin: *');	
//Create a new PHPMailer instance
$mail = new PHPMailer();
$mail->IsSMTP();
 
//Configuracion servidor mail
$mail->From = "aseguratedigitalinfo@gmail.com"; //remitente
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'tls'; //seguridad
$mail->Host = "smtp.gmail.com"; // servidor smtp
$mail->Port = 587; //puerto
$mail->Username ='aseguratedigitalinfo@gmail.com'; //nombre usuario
$mail->Password = 'wfmgbcwxhbioghdc'; //contraseña



$message= " FAVOR DE NO RESPONDER ESTE CORREO\n\n INFORMACION DE CONTACTO\n";
$message.= " Nombre: ".$_POST['Nombre']."\n"." Edad: ".$_POST['Edad']."\n";
$message.= " Telefono: ".$_POST['Telefono'];
$message.= "\n Correo: ".$_POST['Correo'];


//Agregar destinatario
//$mail->AddAddress("aseguratedigitalinfo@gmail.com");
//$mail->AddAddress("o.ortega@sfseguros.net");
$mail->Subject = "INFORMACION DE USUARIO";
$mail->Body =  $message;


//Avisar si fue enviado o no y dirigir al index
if ($mail->Send()) {
    echo"TODO GOOD";
} else {
    echo"NO ENVIADO";
}
  

?>