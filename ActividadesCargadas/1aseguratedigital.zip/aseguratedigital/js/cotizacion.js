var Monto = "";
var Edad ="";
var Fumador ="";
var Sexo ="";
var Mensual ="";

const formulario = document.getElementById('cotizar');
const select = document.querySelectorAll('#cotizar input');

const formulario2 = document.getElementById('formulario2');
const select2 = document.querySelectorAll('#formulario2 input');



const Formulario3 = document.getElementById("Formulario3");
const inputs_formu3 = document.querySelectorAll("#Formulario3 input");

const expresiones =
{
	nombre: /^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos
    correo: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
    telefono: /^(\(\+?\d{2,3}\)[\*|\s|\-|\.]?(([\d][\*|\s|\-|\.]?){6})(([\d][\s|\-|\.]?){2})?|(\+?[\d][\s|\-|\.]?){8}(([\d][\s|\-|\.]?){2}(([\d][\s|\-|\.]?){2})?)?)$/
}

const campos =
 {
    nombre: false,
    correo: false,
    telefono: false
 }



const ir_100 = document.getElementById("Boton100").addEventListener('click',(e)=>{
	 event.preventDefault();
	 Monto = "100,000";
	 Edad = document.getElementById("Edadhide").value;
	 Fumador = document.getElementById("fumadorono").value;
	 Sexo = document.getElementById("Sexo").value;
	 Mensual = document.getElementById("Mes150").value;
	
document.getElementById('Formulario3').classList.add('mostrar');
		 document.getElementById('Formulario3').classList.remove ('oculto');
		  document.getElementById('formulario2').classList.add ('oculto');
		 document.getElementById('formulario2').classList.remove('mostrar');
		
});


const ir_150 = document.getElementById("Boton150").addEventListener('click',(e)=>{
	 event.preventDefault();
	  Monto = "150,000";
	  Edad = document.getElementById("Edadhide").value;
	  Fumador = document.getElementById("fumadorono").value;
	  Sexo = document.getElementById("Sexo").value;
	  Mensual = document.getElementById("Mes150").value;
	
		document.getElementById('Formulario3').classList.add('mostrar');
		 document.getElementById('Formulario3').classList.remove ('oculto');
		  document.getElementById('formulario2').classList.add ('oculto');
		 document.getElementById('formulario2').classList.remove('mostrar');
		
		 				 
});


const ir_250 = document.getElementById("Boton250").addEventListener('click',(e)=>{
	 event.preventDefault();
	 Monto = "250,000";
	 Edad = document.getElementById("Edadhide").value;
	 Fumador = document.getElementById("fumadorono").value;
	 Sexo = document.getElementById("Sexo").value;
	 Mensual = document.getElementById("Mes250").value;
	 
document.getElementById('Formulario3').classList.add('mostrar');
		 document.getElementById('Formulario3').classList.remove ('oculto');
		  document.getElementById('formulario2').classList.add ('oculto');
		 document.getElementById('formulario2').classList.remove('mostrar');
		
		 			
});



const ir_personal = document.getElementById("Botonperso").addEventListener('click',(e)=>{
	 event.preventDefault();


						

	  Monto = document.getElementById("MontoFinal").value;
	  Edad = document.getElementById("Edadhide").value;
	 Fumador = document.getElementById("fumadorono").value;
	  Sexo = document.getElementById("Sexo").value;
	  Mensual = document.getElementById("MesFinal").value;
	
	    				 
		document.getElementById('Formulario3').classList.add('mostrar');
		 document.getElementById('Formulario3').classList.remove ('oculto');
		  document.getElementById('formulario2').classList.add ('oculto');
		 document.getElementById('formulario2').classList.remove('mostrar');
		
});





const ValidarFormulario =(e) =>{
	
	switch (e.target.name)
	{
		case "nombre":
		if ( expresiones.nombre.test(e.target.value))
		{
			document.getElementById("l_nombre").classList.add('labelok');
			document.getElementById("l_nombre").classList.remove('temblar2');
			document.getElementById("nombre").classList.add('inputok');
			document.getElementById("nombre").classList.remove('inputbad')
			campos.nombre = true; 


		}else{
			document.getElementById("l_nombre").classList.add('temblar2');
			document.getElementById("l_nombre").classList.add('labelcolor');
			document.getElementById("l_nombre").classList.remove('labelok');
			document.getElementById("nombre").classList.remove('labelok');
			document.getElementById("nombre").classList.add('inputbad');
			document.getElementById("nombre").classList.remove('inputok');
			
			campos.nombre = false; 
		}
		break;

		case  "correo":
		if ( expresiones.correo.test(e.target.value))
		{
			document.getElementById("l_correo").classList.add('labelok');
			document.getElementById("l_correo").classList.remove('temblar2');
			document.getElementById("correo").classList.add('inputok');
			document.getElementById("correo").classList.remove('inputbad')
			campos.correo =true;

		}else{
			document.getElementById("l_correo").classList.add('temblar2');
			document.getElementById("l_correo").classList.add('labelcolor');
			document.getElementById("l_correo").classList.remove('labelok');
			document.getElementById("correo").classList.remove('labelok');
			document.getElementById("correo").classList.add('inputbad');
			document.getElementById("correo").classList.remove('inputok');

			campos.correo = false;
		}
		break;

		case "telefono":
		if ( expresiones.telefono.test(e.target.value))
		{
			document.getElementById("l_telefono").classList.add('labelok');
			document.getElementById("l_telefono").classList.remove('temblar2');
			document.getElementById("telefono").classList.add('inputok');
			document.getElementById("telefono").classList.remove('inputbad')

			campos.telefono = true;
		}else{
			document.getElementById("l_telefono").classList.add('temblar2');
			document.getElementById("l_telefono").classList.add('labelcolor');
			document.getElementById("l_telefono").classList.remove('labelok');
			document.getElementById("telefono").classList.remove('labelok');
			document.getElementById("telefono").classList.add('inputbad');
			document.getElementById("telefono").classList.remove('inputok');

			campos.telefono = false;
		}
		break;

	}
}



inputs_formu3.forEach((input) => {
			input.addEventListener('keyup', ValidarFormulario);
		    input.addEventListener('blur', ValidarFormulario);
		  
		    input.addEventListener('invalid',ValidarFormulario);
		});

function redireccion() {
  //window.location = "https://aseguratedigital.socialsystemsconnect.com/index.php";
  window.history.go(-2)
}
	
// FINALIZAR 

 const Finalizar = document.getElementById("btn_finalizar").addEventListener('click', (e) =>{
       

 	if (campos.correo == true && campos.telefono == true && campos.nombre == true)
 	 {
 	 event.preventDefault();
        setTimeout('redireccion()',6000);	 //tiempo expresado en milisegundos
 	 	let timerInterval
		Swal.fire({
		  title: '¡Gracias por Contactarnos!',
		  icon: 'success',
		  html: 'Uno de nuestros asesores le estará contactando telefónicamente para completar el registro para la adquisición de su póliza de vida.',
		  background: '#E5EAF8',
		  timer: 6000,
		  timerProgressBar: true,
		  didOpen: () => {
		    Swal.showLoading()
		    timerInterval = setInterval(() => {
		      const content = Swal.getHtmlContainer()
		      if (content) {
		        const b = content.querySelector('b')
		        if (b) {
		          b.textContent = Swal.getTimerLeft()
		        }
		      }
		    }, 100)
		  },
		  willClose: () => {
		    clearInterval(timerInterval)
		  }
		}).then((result) => {
		  /* Read more about handling dismissals below */
		  if (result.dismiss === Swal.DismissReason.timer) {
		    console.log('I was closed by the timer');
		  }
		})


		
 	 }

 	 var Correo = document.getElementById("correo").value;
 	 var Nombre = document.getElementById("nombre").value;
 	 var Telefono = document.getElementById("telefono").value;
 	 $.ajax({
		  url: 'https://aseguratedigital.socialsystemsconnect.com/datoscontacto.php',
		  type: 'POST',
		  data: 'Monto=' + Monto + '&Edad=' + Edad + '&Fumador=' + Fumador+ '&Sexo=' + Sexo + '&Mensual=' + Mensual+"&Correo="+Correo+"&Nombre="+Nombre+"&Telefono="+Telefono,
		  success: function(data) {
		              
		 				 
		            }
		        });	
		        
		        

 });