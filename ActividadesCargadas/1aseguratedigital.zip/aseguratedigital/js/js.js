	
	const formulario = document.getElementById('formulario');
	const select = document.querySelectorAll('#formulario select');



const Formulario3 = document.getElementById("Formulario3");
const inputs_formu3 = document.querySelectorAll("#Formulario3 input");

const expresiones =
{
	nombre: /^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos
    correo: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
    telefono: /^(\(\+?\d{2,3}\)[\*|\s|\-|\.]?(([\d][\*|\s|\-|\.]?){6})(([\d][\s|\-|\.]?){2})?|(\+?[\d][\s|\-|\.]?){8}(([\d][\s|\-|\.]?){2}(([\d][\s|\-|\.]?){2})?)?)$/
}

const campos =
 {
    nombre: false,
    correo: false,
    telefono: false
 }


const DiaMeses = (e) =>
{

		var dias = document.getElementById("dia").value;
		var bisiesto = document.getElementById("año").value;
		var Messeleccionado = document.getElementById("mes").value;

		if ( Messeleccionado == "Abril" || Messeleccionado == "Junio" || Messeleccionado == "Septiembre" || Messeleccionado == "Noviembre")
		{
			if ( dias > 30)
			{
					Swal.fire({
					  icon: 'error',
					  title: 'ERROR ',
					  text: Messeleccionado+' No Puede Tener Más de 30 Días.'
					 
					})

					return 0;
			}
		}else if ( Messeleccionado == "Febrero")
		{
			if ( bisiesto%4 == 0 && ( (bisiesto%100 != 0) || (bisiesto%400 == 0 ) ) )
			{
				if ( dias > 29 ) 
				{
					Swal.fire({
					  icon: 'error',
					  title: 'ERROR ',
					  text: Messeleccionado+' No Puede Tener Más de 29 Días.'
					 
					})

					return 0;
				}
			}else
			{
				if (dias > 28 )
				{
					
						Swal.fire({
						  icon: 'error',
						  title: 'ERROR ',
						  text: Messeleccionado+' No Puede Tener Más de 28 Días.'
						 
						})

						return 0;
					
				}
			}

		}else {
			return 1;
		}
			

}


const ValidarFormulario = (e) =>
{
	switch(e.target.name) // SE RECIBE EL EVENTO PARA COMENZAR A REALIZAR LAS VALIDACIONES 
	{
		case "dia":
		var Dia = document.getElementById('dia').value;

		if (Dia != "Dia")
		{
	      document.getElementById('dia').classList.remove('temblar');
		  document.getElementById('dia').classList.add('ok');
	  
		}else{
		  document.getElementById('dia').classList.add('temblar');
		  document.getElementById('dia').classList.remove ('ok');
		}

		var mes = document.getElementById('mes').value;
		  
		break;

		case "mes":
		console.log("DISTE CLICK AL mes");
		  var meses = document.getElementById("mes").value;
		
	
		   console.log(meses);
		 if (meses != "Mes")
	    {
	    	//var dia = document.getElementById("dia").disabled = false;
	    	var mes = document.getElementById("mes").value;
	    	document.getElementById('mes').classList.remove('temblar');
	    	document.getElementById('mes').classList.add('ok');



	    	 
	    }else
	    {
	    	//var dia = document.getElementById("dia").disabled = true;
	    	//$("#dia").val('Dia');
	    	  document.getElementById('mes').classList.add('temblar');
	    	  document.getElementById('mes').classList.remove('ok');
	    }	
		break;

		case "año":
		console.log("DISTE CLICK AL año");
	    var anio = document.getElementById("año").value;
	    console.log(anio);

	    if (anio != "Año")
	    {
	    	//var mes = document.getElementById("mes").disabled = false;
	    	  document.getElementById('año').classList.remove('temblar');
	    	   document.getElementById('año').classList.add('ok');
  			
	    }else
	    {
	    	//var mes = document.getElementById("mes").disabled = true;
	    	//var dia = document.getElementById("dia").disabled = true;
	    	 document.getElementById('año').classList.add('temblar');
	    	   document.getElementById('año').classList.remove('ok');
	    	// $("#mes").val('Mes');
	    	// $("#dia").val('Dia');
	    }
		break;

	}
}


// PARA VALIDAR EL FORMULARIO #1. 
	select.forEach((sele) => {
		    sele.addEventListener('keyup', ValidarFormulario);
		    sele.addEventListener('blur', ValidarFormulario);
		    sele.addEventListener('change',ValidarFormulario);
		    sele.addEventListener('click',ValidarFormulario)
		});

const Evalua = (dia, mes ,año) =>
{
	var edia = 0;
	var emes = 0;
	var eaño = 0;
 	
	if ( dia == "Dia"){
 		document.getElementById('dia').classList.add('temblar');
 		document.getElementById('dia').classList.remove('ok');
 	}else{
 		document.getElementById('dia').classList.remove('temblar');
 		document.getElementById('dia').classList.add('ok');
 	}

 	if ( mes == "Mes"){
 		document.getElementById('mes').classList.add('temblar');
 		document.getElementById('mes').classList.remove('ok');
 	}else{
 		document.getElementById('mes').classList.remove('temblar');
 		document.getElementById('mes').classList.add('ok');
 	}

 	if ( año == "Año"){
 		document.getElementById('año').classList.add('temblar');
 		document.getElementById('año').classList.remove('ok');
 	}else{
 		document.getElementById('año').classList.remove('temblar');
 		document.getElementById('año').classList.add('ok');
 	}


}



const ir_cotizacion = document.getElementById("btn_ircotizacion").addEventListener('click',(e)=>{
	var mes = document.getElementById("mes").value;
	var dia = document.getElementById("dia").value;
	var año = document.getElementById("año").value;
 
	if ( mes == "Mes" && dia == "Dia" && año == "Año" )
	{
	 event.preventDefault();
	 Evalua(dia,mes,año);
	  
	}else if ( mes == "Mes" && dia == "Dia" && año != "Año")
	{
		 event.preventDefault();
      Evalua(dia,mes,año);
  
	}else if ( mes == "Mes" && dia != "Dia" && año == "Año")
	{
		event.preventDefault();
	 Evalua(dia,mes,año);
	  
	
	}else if ( mes != "Mes" && dia == "Dia" && año == "Año")
	{
		 event.preventDefault();
	  Evalua(dia,mes,año);
	  
	}else if ( mes == "Mes" && dia != "Dia" && año != "Año")
	{
		 event.preventDefault();
	  Evalua(dia,mes,año);
	  
	}else if ( mes != "Mes" && dia == "Dia" && año != "Año")
	{
		event.preventDefault();
	  Evalua(dia,mes,año);
	   
	}else if ( mes != "Mes" && dia != "Dia" && año == "Año")
	{
		event.preventDefault();
	  Evalua(dia,mes,año);
	   
	}else if ( mes != "Mes" && dia != "Dia" && año != "Año")
	{
	  Evalua(dia,mes,año);
	  	var resul = DiaMeses();

		if ( resul == 0 )
		{
			event.preventDefault();
			document.getElementById('dia').classList.add('temblar');
 		document.getElementById('dia').classList.remove('ok');
		}else{
			
			var fecha1 = new Date();
			var edadir = fecha1.getFullYear()-año;
			if ( edadir < 35 )
			{
				event.preventDefault();
				document.getElementById('Formulario3').classList.add('mostrar');
			    document.getElementById('Formulario3').classList.remove ('oculto');
		        document.getElementById('formulario').classList.add ('oculto');
		        document.getElementById('formulario').classList.remove('mostrar');
		
			}
			
		}


	}









});




const ValidarFormulario2 =(e) =>{
	
	switch (e.target.name)
	{
		case "nombre":
		if ( expresiones.nombre.test(e.target.value))
		{
			document.getElementById("l_nombre").classList.add('labelok');
			document.getElementById("l_nombre").classList.remove('temblar2');
			document.getElementById("nombre").classList.add('inputok');
			document.getElementById("nombre").classList.remove('inputbad')
			campos.nombre = true; 


		}else{
			document.getElementById("l_nombre").classList.add('temblar2');
			document.getElementById("l_nombre").classList.add('labelcolor');
			document.getElementById("l_nombre").classList.remove('labelok');
			document.getElementById("nombre").classList.remove('labelok');
			document.getElementById("nombre").classList.add('inputbad');
			document.getElementById("nombre").classList.remove('inputok');
			
			campos.nombre = false; 
		}
		break;

		case  "correo":
		if ( expresiones.correo.test(e.target.value))
		{
			document.getElementById("l_correo").classList.add('labelok');
			document.getElementById("l_correo").classList.remove('temblar2');
			document.getElementById("correo").classList.add('inputok');
			document.getElementById("correo").classList.remove('inputbad')
			campos.correo =true;

		}else{
			document.getElementById("l_correo").classList.add('temblar2');
			document.getElementById("l_correo").classList.add('labelcolor');
			document.getElementById("l_correo").classList.remove('labelok');
			document.getElementById("correo").classList.remove('labelok');
			document.getElementById("correo").classList.add('inputbad');
			document.getElementById("correo").classList.remove('inputok');

			campos.correo = false;
		}
		break;

		case "telefono":
		if ( expresiones.telefono.test(e.target.value))
		{
			document.getElementById("l_telefono").classList.add('labelok');
			document.getElementById("l_telefono").classList.remove('temblar2');
			document.getElementById("telefono").classList.add('inputok');
			document.getElementById("telefono").classList.remove('inputbad')

			campos.telefono = true;
		}else{
			document.getElementById("l_telefono").classList.add('temblar2');
			document.getElementById("l_telefono").classList.add('labelcolor');
			document.getElementById("l_telefono").classList.remove('labelok');
			document.getElementById("telefono").classList.remove('labelok');
			document.getElementById("telefono").classList.add('inputbad');
			document.getElementById("telefono").classList.remove('inputok');

			campos.telefono = false;
		}
		break;

	}
}



inputs_formu3.forEach((input) => {
			input.addEventListener('keyup', ValidarFormulario2);
		    input.addEventListener('blur', ValidarFormulario2);
		  
		    input.addEventListener('invalid',ValidarFormulario2);
		});


	function redireccion() {
  //window.location = "https://aseguratedigital.socialsystemsconnect.com/index.php";
  window.history.go(-1)
        }   
// FINALIZAR 

 const Finalizar = document.getElementById("btn_finalizar").addEventListener('click', (e) =>{

 	if (campos.correo == true && campos.telefono == true && campos.nombre == true)
 	 {
 	 event.preventDefault();
 	 setTimeout ("redireccion()", 6000); //tiempo expresado en milisegundos
 	 	let timerInterval
		Swal.fire({
		  title: '¡Gracias por Contactarnos!',
		  icon: 'success',
		  html: 'Uno de nuestros asesores le estará contactando telefónicamente para completar el registro para la adquisición de su póliza de vida.',
		  background: '#E5EAF8',
		  timer: 6000,
		  timerProgressBar: true,
		  didOpen: () => {
		    Swal.showLoading()
		    timerInterval = setInterval(() => {
		      const content = Swal.getHtmlContainer()
		      if (content) {
		        const b = content.querySelector('b')
		        if (b) {
		          b.textContent = Swal.getTimerLeft()
		        }
		      }
		    }, 100)
		  },
		  willClose: () => {
		    clearInterval(timerInterval)
		  }
		}).then((result) => {
		  /* Read more about handling dismissals below */
		  if (result.dismiss === Swal.DismissReason.timer) {
		    console.log('I was closed by the timer');
		  }
		})


		
 	 }

 	 var Correo = document.getElementById("correo").value;
 	 var Nombre = document.getElementById("nombre").value;
 	 var Telefono = document.getElementById("telefono").value;
 	 	var año = document.getElementById("año").value;
 	 var fecha1 = new Date();
	 var edadir = fecha1.getFullYear()-año;

 	 $.ajax({
		  url: 'https://aseguratedigital.socialsystemsconnect.com/datoscontacto2.php',
		  type: 'POST',
		  data: 'Edad=' + edadir +"&Correo="+Correo+"&Nombre="+Nombre+"&Telefono="+Telefono,
		  success: function(data) {
		              
		 				 
		            }
		        });	

 });

