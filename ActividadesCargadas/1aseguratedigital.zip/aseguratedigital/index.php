 <?php 
 	header('Access-Control-Allow-Origin: *');
 ?>

 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 	<meta http-equiv='cache-control' content='no-cache'>
    <meta http-equiv='expires' content='0'>
    <meta http-equiv='pragma' content='no-cache'>
 	<title>Protege a tus seres queridos</title>
 	<link rel="stylesheet" href="https://aseguratedigital.socialsystemsconnect.com/css/bootstrap.min.css?v=<?php echo time();?>">
 	<link rel="stylesheet" href="https://aseguratedigital.socialsystemsconnect.com/css/estilos.css?v=<?php echo time();?>">
 	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@600&display=swap" rel="stylesheet">
    <style >
			body{
				font-family: Barlow;
			}

		</style>
 </head>
 <body>
	 	
        <form action="enviar.php" method="" id="Formulario3" class="oculto"> <!-- INICIAR FORMULARIO -->

	 		
 	
 		<div class="container"> <!-- INICIAR DIV CONTAINER -->
 			<div class="row"> <!--DIV PRIMER ROW-->
 			    <div class="col">
	    	  		<p class=" color_titulo h2">Ingresa tu información para ponernos en contacto contigo.</p>
	    	  	</div>
 			</div><!--END DIV PRIMER ROW-->


 			<div class="row"> <!--DIV PRIMER ROW-->
 			    <div class="col-lg-4">
 			    	<div style="text-align: left;">
 			    		<label for="nombre" class="estilos_label"> Nombre y Apellido: </label>
 			    	</div>
 			    
	    	  		<div class="form-floating mb-3">
	    	  			 

  						 <input type="text" class="form-control" id="nombre" name= "nombre" placeholder="Jorge Muñoz" required pattern="[a-zA-ZÀ-ÿ\s]{1,40}$" style="padding-top: 30px;">
 						 <label for="nombre_cliente" class="estilos_label2" id="l_nombre" style="padding-top: 5px;">Nombre </label>
					</div>
	    	  	</div>

	    	  	 <div class="col-lg-4">

 			    	<div style="text-align: left;">
 			    		<label for="telefono" class="estilos_label">Número Telefónico  </label>
 			    	</div>
 			    
	    	  		<div class="form-floating mb-3">
  						 <input type="tel" pattern="(\(\+?\d{2,3}\)[\*|\s|\-|\.]?(([\d][\*|\s|\-|\.]?){6})(([\d][\s|\-|\.]?){2})?|(\+?[\d][\s|\-|\.]?){8}(([\d][\s|\-|\.]?){2}(([\d][\s|\-|\.]?){2})?)?)$"  class="form-control" id="telefono" placeholder="55 265 152 25" required name="telefono" style="padding-top: 30px;">
 						 <label for="nombre_cliente" class="estilos_label2" id="l_telefono" style="padding-top: 5px;"> Número </label>
					</div>
	    	  	</div>



	    	  	 <div class="col-lg-4">
 			    	<div style="text-align: left;">
 			    		<label for="correo" class="estilos_label"> Correo Eléctronico:</label>
 			    	</div>
 			    
	    	  		<div class="form-floating mb-3">
  						 <input type="email" name="correo" class="form-control" id="correo" placeholder="name@example.com" required style="padding-top: 30px;">
 						 <label for="nombre_cliente" class="estilos_label2" id="l_correo" style="padding-top: 5px;"> Correo </label>
					</div>
	    	  	</div>
 			</div><!--END DIV PRIMER ROW-->


 			<div class="row"> <!-- DIV ROW COTIZADOR -->
				<div class="col-lg-4 centro"><!-- DIV COL 1  COTIZADOR -->
					<input type="submit" name="" class="btn btn-primary btn_enviar estilos_botones padin" value="Seleccionar" id="btn_finalizar" style="padding-bottom: 45px;">
				</div><!-- END DIV COL 1  COTIZADOR -->
			</div>	<!-- END DIV ROW COTIZADOR -->	
 		</div><!-- END INICIAR DIV CONTAINER -->
 	</form><!--END INICIAR FORMULARIO -->

 	
	 
		 <form action="https://aseguratedigital.socialsystemsconnect.com/cotizacion.php" method="POST" id="formulario" > 
		 

	    	<div class="container"><!-- CONTAINER PRIMARIO  -->
	    	
	    	  <div class="row "> <!-- ROW DE CONTAINER PRIMARIO -->
	    	  
	    	    <div class="col-lg-4 "> <!-- PRIMER COLUMNA DE ROW UNO -->
	    	    
	    	    	<div >
	    	    		<label for="" class="estilos_label">SEXO</label>
	    	    	</div>

	    	      	<div class="btn-group  flex-wrap" role="group" aria-label="Basic radio toggle button group">
		 					 <input type="radio" class="btn-check " name="btnradio" id="btnradio1" value= "Hombre" autocomplete="off"  checked>
		 					 <label class="btn btn-outline-success  " for="btnradio1"> HOMBRE </label>

		 
		  					<input type="radio" class="btn-check " name="btnradio" id="btnradio3"  value= "Mujer"  autocomplete="off" >
		 					<label class="btn btn-outline-success " for="btnradio3"> MUJER </label>
					</div>
	    	      
	    	    </div> <!-- END PRIMER COLUMNA DE ROW UNO -->
	    	    
	    	    <div class="col-lg-5 justify-content-center   color2" ><!-- SEGUNDA COLUMNA  -->

	    	   		<div class="row">
							 
						<div class="col-lg-3" >
							 <label for="dia" class="estilos_label margenbot"> Dia </label>
							<select class="form-select form-select-lg 3  " name="dia"  id="dia">


							  <option selected>Dia</option>
							

							  <?php  
							  	 	for($i=1;$i<=31;$i++) { echo "<option value='".$i."'>".$i."</option>"; } 
								
           					  ?>

							  
							</select>
						</div>
						
						<div class="col-lg-5">
							 <label for="mes" class="estilos_label margenbot"> Mes </label>
							<select class="form-select form-select-lg 3 " required name="mes"  id="mes"> 
							   <option selected >Mes</option>
							   <option >Enero</option>
							   <option >Febrero</option>
							   <option >Marzo</option>
							   <option >Abril</option>
							   <option >Mayo</option>
							   <option >Junio</option>
							   <option >Julio</option>
							   <option >Agosto</option>
							   <option >Septiembre</option>
							   <option >Octubre</option>
							   <option >Noviembre</option>
							   <option >Diciembre</option>
							
							</select>
						</div>

						<div class="col-lg-4" >
							 <label for="año" class="estilos_label margenbot"> Año </label>
							<select class="form-select form-select-lg 3 " required name="año" id= "año">
							  <option selected>Año</option>

							   <?php  
							   
							   	$anio = date("Y");	
							    $inicio = $anio - 65;		
							    $final = $anio - 18;

							 for($i=$final;$i>=$inicio;$i--) { echo "<option value='".$i."'>".$i."</option>"; }

							   	 ?>
							</select>
						</div>
	    	   		</div>


	    	    </div><!-- END SEGUNDA COLUMNA  -->
	    	    
	    	    <div class="  col-lg-3 color3">
	    	     	<div >
	    	    		<label for="" class="estilos_label">¿FUMADOR?</label>

	    	    	</div>

	    	    	<div class="btn-group " role="group" aria-label="Basic radio toggle button group">
				 					 <input type="radio" class="btn-check " name="btnradio2" id="btn_si" value="Si" autocomplete="off" >
				 					 <label class="btn btn-outline-success" for="btn_si">SI</label>

				 
				  					<input type="radio" class="btn-check " name="btnradio2" id="btn_no" autocomplete="off" checked value="No" >
				 					<label class="btn btn-outline-success" for="btn_no">NO </label>
					</div>
	    	    </div>
	    	  </div> <!-- END ROW DE CONTAINER PRIMARIO -->


	    	 <div class="row"> <!-- DIV ROW COTIZADOR -->
				<div class="col-lg-4 centro  "><!-- DIV COL 1  COTIZADOR -->
					<input type="submit" name="" class="btn btn-primary btn_enviar estilos_botones padin" value="Seleccionar" id="btn_ircotizacion" style="padding-bottom: 45px;">
				</div><!-- END DIV COL 1  COTIZADOR -->
			</div>	<!-- END DIV ROW COTIZADOR -->	
            
	    	  
	    	</div><!-- END CONTAINER PRIMARIO  -->
	    	
								 	

	 	</form>
 	

 	<script src="https://aseguratedigital.socialsystemsconnect.com/js/jquery.js"> </script>

 	<script src="https://unpkg.com/@popperjs/core@2"></script>
 	<script src="https://aseguratedigital.socialsystemsconnect.com/js/bootstrap.min.js?v=<?php echo time();?>"></script>
 	<script src="https://aseguratedigital.socialsystemsconnect.com/js/js.js?v=<?php echo time();?>"></script>
 	<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
 	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

 </body>
 </html>