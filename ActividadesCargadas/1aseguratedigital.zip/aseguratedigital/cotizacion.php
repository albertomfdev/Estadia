<?php 


header('Access-Control-Allow-Origin: *');
       $sexo = $_POST["btnradio"];
    $fecha  = $_POST["año"];
    $fumador = $_POST["btnradio2"];

    $anio = date("Y");  
    $edad = $anio - $fecha;    
    
 
    
        $array = [];
        $temp = 35;
        for ($i=0; $i < 31; $i++) 
        { 
        	$array[$i] = $temp;
        	$temp = $temp +1;

        	if ($edad == $array[$i]) 
        	{
       	 		$idEdad  = $i+1;
       	 	}
        }

        $arraymonto = [];
        for ($i=0; $i < 25 ; $i++) { 
        	$arraymonto[$i] = ($i+1);
        }
 $conexion= mysqli_connect('185.201.10.94','u214103417_Asegurate','Digital1234');
	    	 mysqli_select_db($conexion, "u214103417_Primas") or die("No se encuentra la base de datos.");
 
	 	if ( $sexo == "Hombre" && $fumador == "Si")
	    {
	    	 $queryhf= 'SELECT hfumador FROM CantidadMensual where idEdad ='.$idEdad.' AND idMontos <= 25'; 
	    	
	    	 $resultadoshf = mysqli_query($conexion, $queryhf);

	    	 while ($fila=mysqli_fetch_array($resultadoshf, MYSQLI_ASSOC)) 
	    	 {
	            $hombresfumadores[] = $fila; // Añade el array $fila al final de $filas
	      	 }
	    }else if ( $sexo == "Hombre" && $fumador == "No"){
	    	
	    	 $queryhnf= 'SELECT hnfumador FROM CantidadMensual where idEdad ='.$idEdad.' AND idMontos <= 25'; 
	    	
	    	 $resultadoshf = mysqli_query($conexion, $queryhnf);

	    	 while ($fila=mysqli_fetch_array($resultadoshf, MYSQLI_ASSOC)) 
	    	 {
	            $hombresfumadores[] = $fila; // Añade el array $fila al final de $filas
	      	 }

	    }else if ($sexo == "Mujer" && $fumador == "Si"){

	    	 $querymf= 'SELECT mfumadora FROM CantidadMensual where idEdad ='.$idEdad.' AND idMontos <= 25'; 
	    	 $resultadoshf = mysqli_query($conexion, $querymf);

	    	 while ($fila=mysqli_fetch_array($resultadoshf, MYSQLI_ASSOC)) 
	    	 {
	            $hombresfumadores[] = $fila; // Añade el array $fila al final de $filas
	      	 }
	    	
	    }else if ($sexo == "Mujer" && $fumador == "No"){
	    	
	    	 $querymf= 'SELECT mnfumadora FROM CantidadMensual where idEdad ='.$idEdad.' AND idMontos <= 25'; 
	    	 $resultadoshf = mysqli_query($conexion, $querymf);

	    	 while ($fila=mysqli_fetch_array($resultadoshf, MYSQLI_ASSOC)) 
	    	 {
	            $hombresfumadores[] = $fila; // Añade el array $fila al final de $filas
	      	 }
	    }
 	
    

 ?>

 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 	<meta http-equiv='cache-control' content='no-cache'>
    <meta http-equiv='expires' content='0'>
    <meta http-equiv='pragma' content='no-cache'>
 	<title>Elige tu protección</title>
 	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/glider-js@1.7.7/glider.min.css?v=<?php echo time();?>">
 	<link rel="stylesheet" href="https://aseguratedigital.socialsystemsconnect.com/css/bootstrap.min.css?v=<?php echo time();?>">
 	<link rel="stylesheet" href="https://aseguratedigital.socialsystemsconnect.com/css/estilos.css?v=<?php echo time();?>">
 	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://aseguratedigital.socialsystemsconnect.com/css/slider.css?v=<?php echo time();?>">

 <body>
	 	<form action="" method="" id="Formulario3" class="oculto"> <!-- INICIAR FORMULARIO -->

	 		
 	
 		<div class="container"> <!-- INICIAR DIV CONTAINER -->
 			<div class="row"> <!--DIV PRIMER ROW-->
 			    <div class="col">
	    	  		<p class=" color_titulo h2">Ingresa tu información para ponernos en contacto contigo.</p>
	    	  	</div>
 			</div><!--END DIV PRIMER ROW-->


 			<div class="row"> <!--DIV PRIMER ROW-->
 			    <div class="col-lg-4">
 			    	<div style="text-align: left;">
 			    		<label for="nombre" class="estilos_label"> Nombre y Apellido: </label>
 			    	</div>
 			    
	    	  		<div class="form-floating mb-3">
	    	  			 

  						 <input type="text" class="form-control" id="nombre" name= "nombre" placeholder="Jorge Muñoz" required pattern="[a-zA-ZÀ-ÿ\s]{1,40}$" >
 						 <label for="nombre_cliente" class="estilos_label2" id="l_nombre">Nombre </label>
					</div>
	    	  	</div>

	    	  	 <div class="col-lg-4">

 			    	<div style="text-align: left;">
 			    		<label for="telefono" class="estilos_label">Número Telefónico  </label>
 			    	</div>
 			    
	    	  		<div class="form-floating mb-3">
  						 <input type="tel" pattern="(\(\+?\d{2,3}\)[\*|\s|\-|\.]?(([\d][\*|\s|\-|\.]?){6})(([\d][\s|\-|\.]?){2})?|(\+?[\d][\s|\-|\.]?){8}(([\d][\s|\-|\.]?){2}(([\d][\s|\-|\.]?){2})?)?)$"  class="form-control" id="telefono" placeholder="55 265 152 25" required name="telefono">
 						 <label for="nombre_cliente" class="estilos_label2" id="l_telefono"> Número </label>
					</div>
	    	  	</div>



	    	  	 <div class="col-lg-4">
 			    	<div style="text-align: left;">
 			    		<label for="correo" class="estilos_label"> Correo Eléctronico:</label>
 			    	</div>
 			    
	    	  		<div class="form-floating mb-3">
  						 <input type="email" name="correo" class="form-control" id="correo" placeholder="name@example.com" required>
 						 <label for="nombre_cliente" class="estilos_label2" id="l_correo"> Correo </label>
					</div>
	    	  	</div>
 			</div><!--END DIV PRIMER ROW-->


 			<div class="row"> <!-- DIV ROW COTIZADOR -->
				<div class="col-lg-4 centro"><!-- DIV COL 1  COTIZADOR -->
					<input type="submit" name="" class="btn btn-primary btn_enviar estilos_botones " value="Seleccionar" id="btn_finalizar">
				</div><!-- END DIV COL 1  COTIZADOR -->
			</div>	<!-- END DIV ROW COTIZADOR -->	
 		</div><!-- END INICIAR DIV CONTAINER -->
 	</form><!--END INICIAR FORMULARIO -->


 	
	 
		 <form action="" method="POST" id="formulario2" class="mostrar">
		 

	    	<div class="container"><!-- CONTAINER PRIMARIO  -->

	    	  <div class="row">
	    	  	<div class="col">
	    	  		<p class=" color_titulo h2 letra">Empieza a proteger a tus seres queridos hoy.</p>
	    	  	</div>
	    	  </div>
	    		
	    	  	    	<div class="row">
		<div class="col espacio_row_bot">
			<div class="glider-contain">
			  <div class="glider">
			       <div class="row justify-content-center">
				 			     <div class="col-12 fondo3">
				 			     	<div class="card_carrusel"><!-- INICIO CARD -->
				 			     		 <div class="card_header_carrusel"> <!-- INICIO CARD HEADER -->
				 			     		 	<div class="row justify-content-center">
				 			     		 		<div class="col  justify-content-center">
				 			     		 			<div class="centro_carrusel">
							  							<p class="texto_card_carrusel texto_card-signo_carrusel letra">$</p>
							  							<p class="texto_card_carrusel texto_card-cantidad_carrusel "><?php  echo  implode(" ",$hombresfumadores[0]	); ?></p>
							  							<p class="texto_card_carrusel texto_card-mensual_carrusel ">/mensual</p>
							  						</div>
				 			     		 		</div>
				 			     		 	</div> 
				 			     		 </div><!-- END INICIO CARD HEADER -->

				 			     		 <div class="card-body"><!-- INICIO CARD BODY -->
				 			     		 	<div class="row">
				 			     		 		<div class="col">
				 			     		 			<div class="centro_carrusel justify-content-center">
							  						   <p class="texto_card_carrusel texto_card-signo_carrusel centro_carrusel ">Monto Asegurado:</p>
							  		                   <p class="texto_card_carrusel texto_card-cantidad2_carrusel centro_carrusel ">100,000</p>
							  						</div>
				 			     		 		</div>		
				 			     		 	</div>
				 			     		 </div><!--END INICIO CARD BODY -->

				 			     		  <div class="row justify-content-center centro_carrusel">
				 			     		 	 <div class="col-lg-8 col2 centro_carrusel ">
					    	 				    <input type="submit" name="Boton100" class="btn btn-primary btn_enviar_carrusel estilos_botones_carrusel " value="Seleccionar" id="Boton100">
					    	 		         </div>
				 			     		 </div>
				 			     	</div><!-- END INICIO CARD -->
				 			     </div>
				 			</div>
				 			

				 			<div class="row justify-content-center">
				 			     <div class="col-12 fondo3">
				 			     	<div class="card_carrusel"><!-- INICIO CARD -->
				 			     		 <div class="card_header_carrusel"> <!-- INICIO CARD HEADER -->
				 			     		 	<div class="row justify-content-center">
				 			     		 		<div class="col  justify-content-center">
				 			     		 			<div class="centro_carrusel">
							  							<p class="texto_card_carrusel texto_card-signo_carrusel letra">$</p>
							  							<p class="texto_card_carrusel texto_card-cantidad_carrusel "><?php  echo  implode(" ",$hombresfumadores[10]	); ?></p>
							  							<p class="texto_card_carrusel texto_card-mensual_carrusel ">/mensual</p>
							  						</div>
				 			     		 		</div>
				 			     		 	</div> 
				 			     		 </div><!-- END INICIO CARD HEADER -->

				 			     		 <div class="card-body"><!-- INICIO CARD BODY -->
				 			     		 	<div class="row">
				 			     		 		<div class="col">
				 			     		 			<div class="centro_carrusel justify-content-center">
							  						   <p class="texto_card_carrusel texto_card-signo_carrusel centro_carrusel ">Monto Asegurado:</p>
							  		                   <p class="texto_card_carrusel texto_card-cantidad2_carrusel centro_carrusel ">150,000</p>
							  						</div>
				 			     		 		</div>		
				 			     		 	</div>
				 			     		 </div><!--END INICIO CARD BODY -->

				 			     		  <div class="row justify-content-center centro_carrusel">
				 			     		 	 <div class="col-lg-8 col2 centro_carrusel ">
					    	 				    <input type="submit" name="Boton150" class="btn btn-primary btn_enviar_carrusel estilos_botones_carrusel " value="Seleccionar" id="Boton150">
					    	 		         </div>
				 			     		 </div>
				 			     	</div><!-- END INICIO CARD -->
				 			     </div>
				 			</div>
				 			<div class="row justify-content-center">
				 			     <div class="col-12 fondo3">
				 			     	<div class="card_carrusel"><!-- INICIO CARD -->
				 			     		 <div class="card_header_carrusel"> <!-- INICIO CARD HEADER -->
				 			     		 	<div class="row justify-content-center">
				 			     		 		<div class="col  justify-content-center">
				 			     		 			<div class="centro_carrusel">
							  							<p class="texto_card_carrusel texto_card-signo_carrusel letra">$</p>
							  							<p class="texto_card_carrusel texto_card-cantidad_carrusel "><?php  echo  implode(" ",$hombresfumadores[17]	); ?></p>
							  							<p class="texto_card_carrusel texto_card-mensual_carrusel ">/mensual</p>
							  						</div>
				 			     		 		</div>
				 			     		 	</div> 
				 			     		 </div><!-- END INICIO CARD HEADER -->

				 			     		 <div class="card-body"><!-- INICIO CARD BODY -->
				 			     		 	<div class="row">
				 			     		 		<div class="col">
				 			     		 			<div class="centro_carrusel justify-content-center">
							  						   <p class="texto_card_carrusel texto_card-signo_carrusel centro_carrusel ">Monto Asegurado:</p>
							  		                   <p class="texto_card_carrusel texto_card-cantidad2_carrusel centro_carrusel ">250,000</p>
							  						</div>
				 			     		 		</div>		
				 			     		 	</div>
				 			     		 </div><!--END INICIO CARD BODY -->

				 			     		  <div class="row justify-content-center centro_carrusel">
				 			     		 	 <div class="col-lg-8 col2 centro_carrusel ">
					    	 				    <input type="submit" name="Boton250" class="btn btn-primary btn_enviar_carrusel estilos_botones_carrusel " value="Seleccionar" id="Boton250">
					    	 		         </div>
				 			     		 </div>
				 			     	</div><!-- END INICIO CARD -->
				 			     </div>
				 			</div>
			  </div>

			  
			  <div role="tablist" class="dots"></div>
			</div>
		</div>
	</div>


	    	  

	    	  <div class="row ">
	    	  	<div class="col-lg-6 " style="text-align: justify;">

	    	  		<div class="row">
		    	  		
		    	  		<div class="row">
		    	  		  
		    	  		
		    	  		
				      	<div class="row">
				      	  <div class="col margen-top" style="text-align: justify;">
				      	  	<i class="fas fa-check interno color_icono "	></i>
				      		<p class="color_texto letra">Adelanto en vida al asegurado del 80% del monto del seguro en caso que sea diagnosticado con una enfermedad terminal  </p>
				      	  </div>
			    	  	</div>
				    	  		
		    	 	 	</div>

		    	  		
		    	  		
		    	  			<div class="row">
			    	  		  <div class="col margen-top" style="text-align: justify;">
			    	  		  	<i class="fas fa-check interno color_icono"	></i>
			    	  			<p class="color_texto letra">Beneficio de ahorro con una tasa de interés anual del 3%</p>
			    	  		  </div>
		    	  			</div>
		    	  		
	    	       </div>
	    	 	  
	    	</div><!-- END CONTAINER PRIMARIO  -->


	    	<div class="col-lg-6 " style="text-align: justify;">

	    	  		<div class="row">
		    	  		
		    	  		
		    	  		
		    	  			<div class="row">
			    	  		  <div class="col margen-top" style="text-align: justify;">
			    	  		  	<i class="fas fa-check interno color_icono"	></i>
			    	  			<p class="color_texto letra">Cobertura de póliza extendible hasta los 100 años </p>
			    	  		  </div>
		    	  			</div>
		    	  		
	    	       </div>
	    	 	  
	    	</div><!-- END CONTAINER PRIMARIO  -->
	    </div>	
	    
	     <div class="row">
	    	  	<div class="col">
	    	  		<p class=" color_titulo h2 letra espacio">Personalizar Monto Asegurado.</p>
	    	  	</div>
	    	  </div>

		<div class="row" style="margin-top: 5vw;"> <!-- DIV ROW COTIZADOR -->
			<div class="col "><!-- DIV COL 1  COTIZADOR -->
				<p class="  monto_tam letra">Monto Asegurado</p>
			</div><!-- END DIV COL 1  COTIZADOR -->
		</div>	<!-- END DIV ROW COTIZADOR -->	


		<div class="row"> <!-- DIV ROW COTIZADOR -->
			<div class="col "><!-- DIV COL 1  COTIZADOR -->
				<div class="centro2 color " >
					<p class=" cantidad_signo">$</p>
				<div class=" cantidad_body letra" id = "cantidad"></div>
				</div>
				
			</div><!-- END DIV COL 1  COTIZADOR -->
		</div>	<!-- END DIV ROW COTIZADOR -->					 	
			
			<div class="row"> <!-- DIV ROW COTIZADOR -->
				<div class="col color"><!-- DIV COL 1  COTIZADOR -->
					
					<input type="range" class="form-range" min="0" max="24" id="rango">


						
				</div><!-- END DIV COL 1  COTIZADOR -->
			</div>	<!-- END DIV ROW COTIZADOR -->				 	




		<div class="row" style="margin-top: 60px;"> <!-- DIV ROW COTIZADOR -->
			<div class="col "><!-- DIV COL 1  COTIZADOR -->
				<div class="centro">
					    <p class="texto_card texto_card-signo letra">$</p>
						<p class="texto_card texto_card-cantidadfinal letra" id="cantidad_mensual"></p>
						<p class="texto_card texto_card-mensualfinal letra">/mensual</p>
				</div>
			</div><!-- END DIV COL 1  COTIZADOR -->
		</div>	<!-- END DIV ROW COTIZADOR -->	




		<div class="row"> <!-- DIV ROW COTIZADOR -->
			<div class="col-lg-4 centro  "><!-- DIV COL 1  COTIZADOR -->
				<input type="submit" name=" " class="btn btn-primary btn_enviar estilos_botones" value="Seleccionar" id="Botonperso">
			</div><!-- END DIV COL 1  COTIZADOR -->
		</div>	<!-- END DIV ROW COTIZADOR -->	

		<input type="hidden" id="Sexo" name= "Sexo" value="<?php  echo  $sexo; ?>">
		<input type="hidden" id="Edadhide" name= "Edadhide" value="<?php  echo  $edad; ?>">
		<input type="hidden" id="fumadorono" name= "fumadorono" value="<?php  echo  $fumador; ?>">
		<input type="hidden" id="Mes100" name= "Mes100" value="<?php  echo  implode(" ",$hombresfumadores[0]	); ?>">
		<input type="hidden" id="Mes150" name= "Mes150" value="<?php  echo  implode(" ",$hombresfumadores[10]	); ?>">
		<input type="hidden" id="Mes250" name= "Mes250" value="<?php  echo  implode(" ",$hombresfumadores[17]	); ?>">

		<input type="hidden" id="MontoFinal" name="MontoFinal" >
		<input type="hidden" id="MesFinal" name="MesFinal" >





		<script >
						
							var Montos = 
							[

							 "100,000", "105,000","110,000", "115,000","120,000","125,000","130,000"," 135,000","140,000", "145,000","150,000","160,000", "170,000","180,000","190,000","200,000","225,000","250,000","300,000","350,000","400,000","450,000","500,000","750,000", "1,000,000"
							];


							var CantidadMes = 
							[
								'<?php  echo  implode(" ",$hombresfumadores[0]	); ?>', '<?php  echo  implode(" ",$hombresfumadores[1]	); ?>','<?php  echo  implode(" ",$hombresfumadores[2]	); ?>','<?php  echo  implode(" ",$hombresfumadores[3]	); ?>','<?php  echo  implode(" ",$hombresfumadores[4]	); ?>','<?php  echo  implode(" ",$hombresfumadores[5]	); ?>','<?php  echo  implode(" ",$hombresfumadores[6]	); ?>','<?php  echo  implode(" ",$hombresfumadores[7]	); ?>','<?php  echo  implode(" ",$hombresfumadores[8]	); ?>','<?php  echo  implode(" ",$hombresfumadores[9]	); ?>','<?php  echo  implode(" ",$hombresfumadores[10]	); ?>','<?php  echo  implode(" ",$hombresfumadores[11]	); ?>','<?php  echo  implode(" ",$hombresfumadores[12]	); ?>','<?php  echo  implode(" ",$hombresfumadores[13]	); ?>','<?php  echo  implode(" ",$hombresfumadores[14]	); ?>','<?php  echo  implode(" ",$hombresfumadores[15]	); ?>','<?php  echo  implode(" ",$hombresfumadores[16]	); ?>','<?php  echo  implode(" ",$hombresfumadores[17]	); ?>','<?php  echo  implode(" ",$hombresfumadores[18]	); ?>','<?php  echo  implode(" ",$hombresfumadores[19]	); ?>','<?php  echo  implode(" ",$hombresfumadores[20]	); ?>','<?php  echo  implode(" ",$hombresfumadores[21]	); ?>','<?php  echo  implode(" ",$hombresfumadores[22]	); ?>','<?php  echo  implode(" ",$hombresfumadores[23]	); ?>','<?php  echo  implode(" ",$hombresfumadores[24]	); ?>'


							];

							var InputRango = document.querySelector("#rango");
							


						if (InputRango) 
						{
							var Cantidad = document.querySelector("#cantidad");
							var Mensualidad = document.querySelector("#cantidad_mensual");
							
							if (Cantidad)
							{
								
								
								Cantidad.innerHTML = Montos[InputRango.value];
								Mensualidad.innerHTML = CantidadMes[InputRango.value];
								
								var Montof = Montos[InputRango.value];
								var Mesf = CantidadMes[InputRango.value];
								//console.log(Montof);
								var prueba = document.getElementById("MontoFinal");
							 prueba.value = Montos[InputRango.value];

							        var prueba2 = document.getElementById("MesFinal");
							        prueba2.value = CantidadMes[InputRango.value];
								

								InputRango.addEventListener('input', function() {
						        Cantidad.innerHTML =  Montos[InputRango.value];
						        var Montof = Montos[InputRango.value];
						        	Mensualidad.innerHTML = CantidadMes[InputRango.value];

						        	var prueba = document.getElementById("MontoFinal");
							        prueba.value = Montos[InputRango.value];

							        var prueba2 = document.getElementById("MesFinal");
							        prueba2.value = CantidadMes[InputRango.value];

							    }, false);



							}
						}
							 


					</script>
			
	 	</form>
 	



 	


 	<script src="https://aseguratedigital.socialsystemsconnect.com/js/jquery.js?v=<?php echo time();?>"> </script>
 	<script src="https://unpkg.com/@popperjs/core@2"></script>
 	<script src="https://aseguratedigital.socialsystemsconnect.com/js/bootstrap.min.js?v=<?php echo time();?>"></script>
 	<script src="https://aseguratedigital.socialsystemsconnect.com/js/cotizacion.js?v=<?php echo time();?>"></script>
 	<script src="https://cdn.jsdelivr.net/npm/glider-js@1.7.7/glider.min.js"></script>
 	<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
 	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
 	 <script src="https://aseguratedigital.socialsystemsconnect.com/js/slider.js?v=<?php echo time();?>"></script>

 </body>
 </html>